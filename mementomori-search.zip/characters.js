const characters = [
  {
    name: "アイリス",
    attribute: "火",
    weapon: "剣",
    cv: "花澤香菜",
    image: "images/iris.png"
  },
  {
    name: "ロザリー",
    attribute: "水",
    weapon: "弓",
    cv: "内田真礼",
    image: "images/rosalie.png"
  }
];